# Converts the cases into uppercase and lowercase 


str = input("Enter the string : ");
str = str.upper();
print(str);