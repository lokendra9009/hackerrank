#demo
#multiple input in a single line
inp = input()
#res = []
res = list(map(int,inp.split()));
print(res);

