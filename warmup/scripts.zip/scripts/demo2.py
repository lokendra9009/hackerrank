#demo2

no_of_tc = int(input());
inp = [];
n=0;
while (n<no_of_tc):
	inp.append(input());
	n+=1
print (inp);